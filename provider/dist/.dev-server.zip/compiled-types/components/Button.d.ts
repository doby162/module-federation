import React from 'react';
declare const Button: React.FC;
export default Button;
